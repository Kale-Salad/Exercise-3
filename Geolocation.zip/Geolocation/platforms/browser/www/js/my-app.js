var app = new Framework7({

  // App root element
  root: '#app',
  // ... other parameters

});

var mainView = app.views.create('.view-main');

    document.addEventListener("deviceready", onDeviceReady, false);
    function onDeviceReady() {
       // console.log("navigator.geolocation works well");
        
        var geoOpts = { enableHighAccuracy: true;
                    maximumAge: 3000;
                    timeout: 5000;
                   }
        var watchID; 
        
        var map = new google.maps.Map(document.getElementById('map'), {
            zoom: 10,
            center: {lat: 41, lng: 151}
            });
        var marker = new google.maps.Marker({
            position: {lat: 41, lng: 151},
            map: map
        });

        
         $("#geobtn").on("click", function() {
         navigator.geolocation.getCurrentPosition(geoSuccess, geoError, geoOpts)    
         }    )
        

        $("#startWatch").on("click", function() {
            watchID = navigator.geolocation.watchPosition(success, error);
        });
        $("#stopWatch").on("click", function() {
            navigator.geolocation.clearWatch(watchID);
        }); 
        
        $$(document).on('page:init', ‘.page[data-name="two"]', function () {
                        navigator.geolocation.getCurrentPosition(geoSuccess, geoError, geoOpts);
            })
    
    function cameraSuccess(imageData) {
        navigator.geolocation.getCurrentPosition(geoSuccess, geoError, geoOpts)
        navigator.geolocation.watchPosition(geoSuccess, geoError, geoOpts)
    }
        
        var watchID, map, marker;

        function geoSuccess(position){
            var lat = position.coords.latitude;
            var long = position.coords.longitude;
            
            map = new google.maps.Map(document.getElementById('map'), {
            zoom: 10,
            center: {
            lat: position.coords.latitude,
            lng: position.coords.longitude
            }
            });
            marker = new google.maps.Marker({
            position: {
            lat: position.coords.latitude,
            lng: position.coords.longitude
            },
            map: map
            
        }
                                            
        watchID = navigator.geolocation.watchPosition(watchSuccess, geoError, geoOpts); 
            
            function watchSuccess(position) {
            marker.setPosition({
            lat: position.coords.latitude,
            lng: position.coords.longitude
             });
            } 
            
            map.setCenter(coords);
            marker.setPosition(coords); 
                                            
        function error(message) {
            alert("error: " + message.message);
        }
        
navigator.geolocation.getCurrentPosition(geoSuccess, geoError, geoOpts);
        
    }